bool break case const continue default else false for func go if import int nil print println real return string struct switch true type var void while

, : ; ( ) [ ] { }

+ - * / ^ % < <= > >= != & | ! = += -= /= *= 

"cat"

*/CanYouFindThisID"???"

///* Hello World Example /****************/
/*
//==//
I am cat
yo yo yo~~~~~~
這 裡 可 以 違 法～～～～＾＿＾

*/
//\n

/*
\n
"xDDD"
lala
*/

//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\ㄕㄨㄣ 

bool a = true;

//\n
/*Hello World 你好*/
/* iwjrioewq   //"" 你好 WorldExample */

func main ( ) {
	a = 5;
	b = 5.0e-10;
	b = 5.0e+10;
	b = 5.0E-1;
	b = 5.0E+10;
	c = 5.0;
	c = 5.0E10;
	c = 5.0e10;
	d = "aa""bb";
	d = "x"""""""x;
	d = "aa"c"bb"d;
	d = "aa"""""c"bb"d"";
	d = "~www~"w"!!!!!!-_-";
    println "Hello World";
    println ab //123
    println "bb" //123
    println "aa""bb" //123
}
Hi I am final test :))))))))))))))))