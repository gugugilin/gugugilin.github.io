//test declarations
var a real = 5.5 + 5
var a[100]int
var a int = 5
var a int = -5
var a real = 5.5E+10
var a real = -5.5E+10
var a real = +5.5E+10
var a real = 5.5E-10
var a real = -5.5E-10
var a real = +5.5E-10
var a int =5+3
var a real =5+3
var a real =+5.5E-10 - -5.5E-10
var a bool = true
var a bool = false&true
var a bool = !false
var a string = "test"
var a int
var a real
var a bool
var a bool
var a string
const a  = 5
const a  = -5
const a  = 5.5E+10
const a  = -5.5E+10
const a  = +5.5E+10
const a  = 5.5E-10
const a  = -5.5E-10
const a  = +5.5E-10
const a  =5+3
const a  =5+3
const a  =+5.5E-10 - -5.5E-10
const a  = false&true
const a  = true
const a  = !false
const a  = "test"