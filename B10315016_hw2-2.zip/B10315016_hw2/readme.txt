文件說明：
	lex檔案名稱為hw1.l
	預設的測資名字為HelloWorld.go (FILE *fp = fopen("HelloWorld.go", "r");)

操作方式：
	編譯只需打一個指令make
	打完之後./a.out 即可執行
