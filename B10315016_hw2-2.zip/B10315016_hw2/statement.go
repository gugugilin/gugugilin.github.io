//test statement with int_exp
a[3+8]=10
a[-3]=10
a[-3]=a[3+8]
a[(((3+8.6)-2*2)/3)^2]=-(((3+8.6)-2*2)/3)^2
print 5
print -(((3+8.6)-2*2)/3)^2
println 5
println -(((3+8.6)-2*2)/3)^2
return -(((3+8.6)-2*2)/3)^2
return a[3+8]
//test statement with bool_exp
a = true
a[3+8]=true
a[-3]=true
a[(((3+8)-2*2)/3)^2]=!(true&true)&(true|true)
print true
print !(true&true)&(true|true)
println false
println !(true&false)&(true|false)
return !(true&true)&(true|true)
//test statement with constant
a="test"
read a
return 
