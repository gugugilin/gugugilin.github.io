var a real = 5.5E+10
var b real = 5.5E+10
var c real = +5.5E+10
var d real = -5.5E+10

print a - 5
// "Hello World"aaa"aaaaaaaa"
print 3-5
var lala string = "test"
print 3-5
// var lala string = "test"
// var a int = 5
// func main ( ) {
    // println "Hello World"
// }
